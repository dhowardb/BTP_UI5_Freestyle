module.exports = require("./generators/app");
