sap.ui.define(["<%= controllerToExtend%>"], function (Controller) {
    "use strict";

    return Controller.extend("<%=appId%>.controller.<%=viewname%>", {});
});
